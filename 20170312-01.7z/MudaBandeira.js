//Catapulta (alterana imagens - catapulta em baixo - catapulta em cima - 
function MudaBandeira(){
if (XPos) === 130 && YPos === 270){
	 var bandeiraConquista = document.getElementById("catapulta");
	//var bandeiraConquista = document.getElementById("catapulta");
	bandeiraConquista.style.top=130+"px";
	bandeiraConquista.style.left=260+"px";
	 
}







}