function Key(e) {

	if (dispara === 550 && XPos > 300) inicia();// efeito da catapulta

	if  (XPos > 920) left(); //limites do jogo
	if  (XPos < 0) right();//limites do jogo
	if (YPos < 0) down();//limites do jogo
	if  (YPos > 770) up();//limites do jogo
	if (contador === 7){
	alert ("Parabens conquistou 7 territorios");
}
	
	if (e.keyCode===37) left();//movimento do pinguim
	if (e.keyCode===38) up();
	if (e.keyCode===39) right();
	if (e.keyCode===40) down();
	
	
	
	
	
	
}




