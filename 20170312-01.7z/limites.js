	
function limite(){
    switch (XPos) {
		
		
		
		
        case  < 0 :  /*seta para direita*/
            //if (x + dx < WIDTH){
				
               
			  stop(); 
			   
			   
				
            break;  


				
    }

}