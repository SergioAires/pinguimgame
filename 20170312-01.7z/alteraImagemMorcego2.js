

function changeImage2()
{

 
	var altimg2 = document.getElementById("img2");
	
	altimg2.style.top = 210+"px";
	altimg2.style.left = Math.random() * (370 - 270) + 270+"px"; //Math.random() * (max - min) + min
	
    img2.src = images[x2];  //aqui tem que ficar img.src ... não alterar para altimg
    x2++;
	
    
	if(x2 >= images.length){
        x2 = 0;    // garante que quando chega à ultima imagem do array, volta à primeira
    } 

    fadeImg(altimg2, 100, true);
    setTimeout("changeImage2()", 500); //intervalo de tempo para mudar de imagem


function fadeImg(el, val, fade){
    if(fade === true){
        val--;
    }else{
       val ++;
    }

}
}
var images = [];
x2 = 0;

images[0] = "morcego1.png";
images[1] = "morcego2.png";
images[2] = "morcego3.png";
images[3] = "morcego4.png";

setTimeout("changeImage2()", 1000);// após este tempo inicia o ciclo de imagens
