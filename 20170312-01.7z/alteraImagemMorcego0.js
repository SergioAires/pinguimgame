

function changeImage0()
{ 
 
	var altimg0 = document.getElementById("img0");
	
	altimg0.style.top = 210+"px";
	altimg0.style.left = Math.random() * (100 - 0) + 0+"px"; //Math.random() * (max - min) + min
	
    img0.src = images[x0];  //aqui tem que ficar img.src ... não alterar para altimg
    x0++;
	
    
	if(x0 >= images.length){
        x0 = 0;    // garante que quando chega à ultima imagem do array, volta à primeira
    } 

    fadeImg(altimg0, 100, true);
    setTimeout("changeImage0()", 500); //intervalo de tempo para mudar de imagem


function fadeImg(el, val, fade){
    if(fade === true){
        val--;
    }else{
       val ++;
    }
	
}
}
var images = [];
x0 = 0;

images[0] = "morcego1.png";
images[1] = "morcego2.png";
images[2] = "morcego3.png";
images[3] = "morcego4.png";


setTimeout("changeImage0()", 1000);// após este tempo inicia o ciclo de imagens
