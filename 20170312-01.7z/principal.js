    var tela, contexto,  vx, vy, r, tframe, t, nf, dt, xo, yo, x, y, iter, LimpaSempre, LimpaInicio, dispara; //novo
    var MaxHeight, MaxWidth, YPos, XPos,contador = 0,interval1, interval2, interval3, interval4, moveTo;
	var BandeiraConq1 = 0, BandeiraConq2 = 0 , BandeiraConq3 = 0, BandeiraConq4 = 0, BandeiraConq5 = 0, BandeiraConq6 = 0, BandeiraConq7 = 0; 

	
	
	
	
	
function up(){ // cima
	var myclass = new Array('back-right','back-stand','back-left');
	var n= Math.round(Math.random()*2);
	document.getElementById('character').setAttribute('class',myclass[n]);
	var a = document.getElementById('character').style.top;
	if (a==0) a="0"; //inicia na posição 0
	b=parseInt(a)-10;
	if (YPos >= 240 && YPos <= 280 && XPos >= 120 && XPos <= 140 && BandeiraConq1 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 250+"px";
		Nbandeira.style.left = 150+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq1 = 1;
		}
		
		if (YPos >= 620 && YPos <= 650 && XPos >= 320 && XPos <= 350 && BandeiraConq2 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 620+"px";
		Nbandeira.style.left = 340+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq2 = 1;
		}
		
			if (YPos >= 660 && YPos <= 680 && XPos >= 570 && XPos <= 590 && BandeiraConq3 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 680+"px";
		Nbandeira.style.left = 580+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq3 = 1;
		}
		
				if (YPos >= 430 && YPos <= 480 && XPos >= 390 && XPos <= 430 && BandeiraConq4 < 1){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 460+"px";
		Nbandeira.style.left = 410+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq4 = 1;
		}

		
					if (YPos >= 250 && YPos <= 290 && XPos >= 420 && XPos <= 480 && BandeiraConq5 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 270+"px";
		Nbandeira.style.left = 450+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq5 = 1;
		}
		
		if (YPos >= 250 && YPos <= 290 && XPos >= 610 && XPos <= 650 && BandeiraConq6 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 270+"px";
		Nbandeira.style.left = 650+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq6 = 1;
		}
		
			if (YPos >= 620 && YPos <= 680 && XPos >= 650 && XPos <= 690 && BandeiraConq7 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 610+"px";
		Nbandeira.style.left = 670+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq7 = 1;
		}
		
	document.getElementById('character').style.top=b+"px";//nova posição do pinguim
	YPos = document.getElementById("resultadosY").innerHTML=b; //para dar a coordenada em Y
	dispCatapulta();//chamada da função dispara catapulta
}


function down(){// baixo
	var myclass = new Array('front-right','front-stand','front-left');
	var n= Math.round(Math.random()*2);
	document.getElementById('character').setAttribute('class',myclass[n]);
	var a = document.getElementById('character').style.top;
	if (a==0) a="0";
	b=parseInt(a)+10;
	if (YPos >= 240 && YPos <= 280 && XPos >= 120 && XPos <= 140 && BandeiraConq1 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 250+"px";
		Nbandeira.style.left = 150+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq1 = 1;
		}
		
		if (YPos >= 620 && YPos <= 650 && XPos >= 320 && XPos <= 350 && BandeiraConq2 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 620+"px";
		Nbandeira.style.left = 340+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq2 = 1;
		}
		
			if (YPos >= 660 && YPos <= 680 && XPos >= 570 && XPos <= 590 && BandeiraConq3 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 680+"px";
		Nbandeira.style.left = 580+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq3 = 1;
		}
		
				if (YPos >= 430 && YPos <= 480 && XPos >= 390 && XPos <= 430 && BandeiraConq4 < 1){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 460+"px";
		Nbandeira.style.left = 410+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq4 = 1;
		}

		
					if (YPos >= 250 && YPos <= 290 && XPos >= 420 && XPos <= 480 && BandeiraConq5 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 270+"px";
		Nbandeira.style.left = 450+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq5 = 1;
		}
		
		if (YPos >= 250 && YPos <= 290 && XPos >= 610 && XPos <= 650 && BandeiraConq6 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 270+"px";
		Nbandeira.style.left = 650+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq6 = 1;
		}
		
			if (YPos >= 620 && YPos <= 680 && XPos >= 650 && XPos <= 690 && BandeiraConq7 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 610+"px";
		Nbandeira.style.left = 670+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq7 = 1;
		}

	document.getElementById('character').style.top=b+"px";
	document.getElementById("resultadosY").innerHTML=b;

	dispCatapulta();//chamada da função dispara catapulta
	if (XPos == 150 && YPos == 150){
	morcego = 900;
	document.getElementById("catapulta").style.top=100+"px";
	}
	YPos = document.getElementById("resultadosY").innerHTML=b;
	if (XPos === 130 && YPos === 270){
		document.getElementById("catapulta").style.top=100+"px";
		 
}
}

function right(){ //direita
	var myclass = new Array('right-right','right-stand','right-left');
	var n= Math.round(Math.random()*2);
	document.getElementById('character').setAttribute('class',myclass[n]);
	var a = document.getElementById('character').style.left;
	if (a==0) a="0";
	b=parseInt(a)+10;
	if (YPos >= 240 && YPos <= 280 && XPos >= 120 && XPos <= 140 && BandeiraConq1 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 250+"px";
		Nbandeira.style.left = 150+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq1 = 1;
		}
		
		if (YPos >= 620 && YPos <= 650 && XPos >= 320 && XPos <= 350 && BandeiraConq2 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 620+"px";
		Nbandeira.style.left = 340+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq2 = 1;
		}
		
			if (YPos >= 660 && YPos <= 680 && XPos >= 570 && XPos <= 590 && BandeiraConq3 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 680+"px";
		Nbandeira.style.left = 580+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq3 = 1;
		}
		
				if (YPos >= 430 && YPos <= 480 && XPos >= 390 && XPos <= 430 && BandeiraConq4 < 1){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 460+"px";
		Nbandeira.style.left = 410+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq4 = 1;
		}

		
					if (YPos >= 250 && YPos <= 290 && XPos >= 420 && XPos <= 480 && BandeiraConq5 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 270+"px";
		Nbandeira.style.left = 450+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq5 = 1;
		}
		
		if (YPos >= 250 && YPos <= 290 && XPos >= 610 && XPos <= 650 && BandeiraConq6 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 270+"px";
		Nbandeira.style.left = 650+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq6 = 1;
		}
		
			if (YPos >= 620 && YPos <= 680 && XPos >= 650 && XPos <= 690 && BandeiraConq7 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 610+"px";
		Nbandeira.style.left = 670+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq7 = 1;
		}

	document.getElementById('character').style.left = b+"px";
	XPos = document.getElementById("resultadosX").innerHTML=b;// para apresentar a coordenada em X
}

function left(){//esquerda
	var myclass = new Array('left-right','left-stand','left-left');
	var n= Math.round(Math.random()*2);
	document.getElementById('character').setAttribute('class',myclass[n]);
	var a = document.getElementById('character').style.left;
	if (a==0) a="0";
	b=parseInt(a)-10;
	if (YPos >= 240 && YPos <= 280 && XPos >= 120 && XPos <= 140 && BandeiraConq1 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 250+"px";
		Nbandeira.style.left = 150+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq1 = 1;
		}
		
		if (YPos >= 620 && YPos <= 650 && XPos >= 320 && XPos <= 350 && BandeiraConq2 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 620+"px";
		Nbandeira.style.left = 340+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq2 = 1;
		}
		
			if (YPos >= 660 && YPos <= 680 && XPos >= 570 && XPos <= 590 && BandeiraConq3 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 680+"px";
		Nbandeira.style.left = 580+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq3 = 1;
		}
		
				if (YPos >= 430 && YPos <= 480 && XPos >= 390 && XPos <= 430 && BandeiraConq4 < 1){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 460+"px";
		Nbandeira.style.left = 410+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq4 = 1;
		}

		
					if (YPos >= 250 && YPos <= 290 && XPos >= 420 && XPos <= 480 && BandeiraConq5 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 270+"px";
		Nbandeira.style.left = 450+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq5 = 1;
		}
		
		if (YPos >= 250 && YPos <= 290 && XPos >= 610 && XPos <= 650 && BandeiraConq6 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 270+"px";
		Nbandeira.style.left = 650+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq6 = 1;
		}
		
			if (YPos >= 620 && YPos <= 680 && XPos >= 650 && XPos <= 690 && BandeiraConq7 < 1 ){
	var Nbandeira = document.getElementById("bandeiras");
		Nbandeira.style.top = 610+"px";
		Nbandeira.style.left = 670+"px";
		contador ++;
		document.getElementById("contador").innerHTML=contador;
		BandeiraConq7 = 1;
		}

	document.getElementById('character').style.left = b+"px";
	document.getElementById("resultadosX").innerHTML=b;

	XPos = document.getElementById("resultadosX").innerHTML=b;
}


 // Função de lançamento de projectil
      function inicia (formulario){
         //variáveis locais
        var xmax, ymax, mensagem, tg, tr, v;
 
        tela = document.getElementById('minhaTela');
        contexto = tela.getContext('2d');
       
        tg = 45.0; //angulo inicial
        v = 50;//Velocidade
        r = 8.0;//Raio da particula
        nf = 70;// número de frames
        tframe = 1000.0/60.0; // tempo entre frames
        LimpaInicio = true;        
 
        //converte para radianos
        tr = (Math.PI / 180.0)*tg;
 
        //componentes da velocidade
        vx = v * Math.cos(tr);
        vy = v * Math.sin(tr);
 
        //Calculo do tempo de voo
        tv = 2.0*vy / 9.8;
 
        //Calculo do alcance maximo
        xmax = vx * tv;
        dt = tv / nf;
 
		if (xmax > (tela.width-4.0*r)){
          mensagem = 'A canva tem '+tela.width+ '\nO projetil vai atingir Xmax = '+xmax;
          alert(mensagem);
          dt = ((tela.width-4.0*r) / vx) / nf;
        }
 
		//altura maxima
        ymax = vy * (tv / 2.0)-4.9*(tv / 2.0)*(tv / 2.0);
        if (ymax > (tela.height-4.0*r)){
          mesagem = 'A canva tem '+tela.height+ '\nO projetil vai atingir Ymax = '+ymax;
          alert(mensagem);
        }
         
        xo = 18.0*r;
		yo = tela.height-30.0*r;// indica onde o projectil vai iniciar e cair (em y) tela.height-2 (inicia e termina 2 pontos acima do limite inferior)
        anima();
      }
 
 function anima(){
        x = xo;
        y = yo;
        t = -dt;
        iter = -1;
 
       LimpaSempre = true;
 
       tempo = setInterval("move()", tframe);
      }
 
 
 
 
 
 
 
 function para() {
        clearInterval(tempo);
      }

	  function move(){
        if (iter < nf){
 
          //caso verdadeiro só mostra o ponto pelo ar
          if (LimpaSempre){
            contexto.clearRect(0, 0, tela.width, tela.height);
          }
 
          //equações de movimento
          t = t + dt;
          x = xo + vx * t;
          y = yo - vy * t + 4.9 * t*t;
 
          contexto.beginPath();
          contexto.arc(x, y, r, 0, 2.0*Math.PI, true);
          contexto.lineWidth = 2;
          contexto.strokeStyle = 'blue';
          contexto.fillStyle = 'yellow'
          contexto.fill();
          contexto.stroke();
 
          iter++;
        } else{
          clearInterval(tempo);
        }
      }
	  
	  
	  
	  
	  
	  