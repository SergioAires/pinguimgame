
//Catapulta (alterana imagens - catapulta em baixo - catapulta em cima - 
function dispCatapulta(){
dispara = (document.getElementById('character').style.top=b);
//alert(dispara)
var minhaclasse = new Array ('catapulta1', 'catapulta2');
//alert(b)
if (b == 540){
document.getElementById('catapulta').setAttribute('class',minhaclasse[1]);
document.getElementById('catapulta').style.top=550+"px";
lancamento = 1;
}

if (lancamento === 1 && b === 550){
document.getElementById('catapulta').setAttribute('class',minhaclasse[2]);
document.getElementById('catapulta').style.top=550+"px";
lancamento = 0;
}
}