

function changeImage1()
{

 
	var altimg1 = document.getElementById("img1");
	
	altimg1.style.top = 210+"px";
	altimg1.style.left = Math.random() * (260 - 160) + 160+"px"; //Math.random() * (max - min) + min
	
    img1.src = images[x1];  //aqui tem que ficar img.src ... não alterar para altimg
    x1++;
    
	if(x1 >= images.length){
        x1 = 0;    // garante que quando chega à ultima imagem do array, volta à primeira
    } 

    fadeImg(altimg1, 100, true);
    setTimeout("changeImage1()", 500); //intervalo de tempo para mudar de imagem


function fadeImg(el, val, fade){
    if(fade === true){
        val--;
    }else{
       val ++;
    }
	
}
}
var images = [];
x1 = 0;

images[0] = "morcego1.png";
images[1] = "morcego2.png";
images[2] = "morcego3.png";
images[3] = "morcego4.png";



setTimeout("changeImage1()", 1000);// após este tempo inicia o ciclo de imagens
